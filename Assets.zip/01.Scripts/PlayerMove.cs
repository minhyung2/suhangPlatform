using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMove : MonoBehaviour
{

    public float movePower = 1f;
    public float jumpPower = 1f;
    public int stage = 1;

    Rigidbody2D rigid;
    SpriteRenderer ren;
    Animator animator;
    public GameObject coinparent1;
    public GameObject coinparent2;

    public CanvasGroup canvas;

    Vector3 movement;
    Vector2 playerPos;
    bool isJumping = false;

    //�Ҹ��� ���� isGround ��°� �����
    public LayerMask whatIsGround;
    public Transform groundChecker;
    public bool isGround;

    void Start()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
        ren = gameObject.GetComponentInChildren<SpriteRenderer>();
        animator = gameObject.GetComponent<Animator>();
    }

    void Update()
    {
        if(stage == 1)
        {
            if (coinparent1.transform.childCount == 0)
            {
                canvas.gameObject.SetActive(true);
                Time.timeScale = 0;
            }
        }
        else if (stage == 2)
        {
            if (coinparent1.transform.childCount == 0)
            {
                canvas.gameObject.SetActive(true);
                Time.timeScale = 0;
            }
        }

        playerPos = this.gameObject.transform.position;
        if (playerPos.y < -6)
        {
            Debug.Log("OVER");
            Destroy(gameObject);

            canvas.alpha = 1;
        }

        if(Input.GetAxisRaw("Horizontal") == 0)
        {
            animator.SetBool("isMoving", false);
        }
        else if(Input.GetAxisRaw("Horizontal") < 0)
        {
            animator.SetBool("isMoving", true);
            ren.flipX = true;
        }
        else if(Input.GetAxisRaw("Horizontal") > 0)
        {
            animator.SetBool("isMoving", true);
            ren.flipX = false;
        }

        animator.SetFloat("Yspeed", rigid.velocity.y); // Yspeed�� y ��ǥ�� ���� ��ġ�� ����־� -1���� �϶��� �������� 1�̻��Ϥ�°�� �ö󰡴� �ִϸ��̼� ����
        animator.SetBool("isGround", isGround); // isGround�� true�϶� �ൿ�� �����ǰ� false�϶� �ൿ�ϰ� �ִϸ��̼� �Է�

        if(Input.GetButtonDown("Jump") && animator.GetBool("isGround"))
        {
            isJumping = true;
            // animator.SetBool("isJunmping", true);
            // animator.SetTrigger("isGround");
        }
    }
    void FixedUpdate()
    {
        Move();
        isGround = Physics2D.OverlapCircle(groundChecker.position, 0.2f, whatIsGround); // ���� ����ִ��� üũ�� true, false�� �ٲ�
        Jump();
        
    }
    void Move() // �̵�����
    {
        float moveX = Input.GetAxisRaw("Horizontal");
        // Debug.Log(moveX* movePower);
        rigid.velocity = new Vector2(moveX * movePower, rigid.velocity.y);
        
        //transform.position += moveSpeed * movePower * Time.deltaTime;
    }
    void Jump() // ��������
    {
        if (!isJumping) // ���������� üũ
        {
            return;
        }

        //rigid.velocity = Vector2.zero;

        Vector2 jumpSpeed = new Vector2(0, jumpPower);
        rigid.AddForce(jumpSpeed, ForceMode2D.Impulse);
        isJumping = false;
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.tag == "Coin")
        {
            BlockStatus coin = other.gameObject.GetComponent<BlockStatus>();
            ScoreManager.setScore((int)coin.value);
            Destroy(other.gameObject, 0f);
        }

    }
}
