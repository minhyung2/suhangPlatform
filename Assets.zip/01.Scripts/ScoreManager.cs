using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ScoreManager : MonoBehaviour
{
    static int score = 0;
    public Text Scoretext;
    public GameObject coinparent;
    PlayerMove playerMove;

    string a;

    void Start()
    {
        a = coinparent.transform.childCount.ToString();
        score = 0;
    }

    void Update()
    {
        scoreUI();
    }
    public static void setScore(int value)
    {
        score += value;
    }

    public static int getScore()
    {
        return score;
    }

    void scoreUI()
    {
        Scoretext.text = $"COIN : {coinparent.transform.childCount.ToString()} / {a}";
    }

    public void Restart()
    {
        SceneManager.LoadScene(0);
    }

    public void nextStage()
    {
        // playerMove.stage++;
        // gameObject.transform.position.x = gameObject.transform.position.x + 30;
    }
}
