using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockStatus : MonoBehaviour
{
    public string type;
    public float value = 0f;
}
