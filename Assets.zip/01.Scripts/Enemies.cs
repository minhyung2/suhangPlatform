using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Enemies : MonoBehaviour
{
    public float movePower = 1f;
    bool isTracing;

    public CanvasGroup canvas;

    Animator animator;
    GameObject traceTarget;
    int movementFlag = 0;

    void Start()
    {
        animator = gameObject.GetComponentInChildren<Animator>();

        StartCoroutine("ChangeMovement");
    }

    void FixedUpdate()
    {
        Move();
    }
    void Move()
    {
        Vector3 moveVelocity = Vector3.zero;
        string dist = "";

        // if(movementFlag == 1)
        // {
        //     moveVelocity = Vector3.left;
        //     transform.localScale = new Vector3(1, 1, 1);
        // }
        // else if (movementFlag == 2)
        // {
        //     moveVelocity = Vector3.right;
        //     transform.localScale = new Vector3(-1, 1, 1);
        // }

        if(isTracing)
        {
            Vector3 playerPos = traceTarget.transform.position;

            float check = playerPos.x - transform.position.x;

            if(playerPos.x < transform.position.x)
            {
                dist = "Left";
            }
            if(playerPos.x > transform.position.x)
            {
                dist = "Right";
            }
            if(check < 0.1 && check > -0.1)
            {
                dist = "";
            }
        }

        if( dist == "Left")
        {
            moveVelocity = Vector3.left;
            transform.localScale = new Vector3(1, 1, 1);
        }
        if( dist == "Right")
        {
            moveVelocity = Vector3.right;
            transform.localScale = new Vector3(-1, 1, 1);
        }
        if( dist == "")
        {
            animator.SetBool("isMoving", false);

            // moveVelocity = Vector3.zero;
            // transform.localScale = new Vector3(0, 1, 1);
            // Debug.Log("����");
        }

        transform.position += moveVelocity * movePower * Time.deltaTime;
    }

    IEnumerator ChangeMovement()
    {
        // Debug.Log("Front Logic : " + Time.time);
        // 
        // yield return new WaitForSeconds(5f);
        // 
        // Debug.Log("Behind Logic : " + Time.time);

        movementFlag = Random.Range(0, 3);

        if(movementFlag == 0)
        {
            animator.SetBool("isMoving", false);
        }
        else
        {
            animator.SetBool("isMoving", true);
        }

        yield return new WaitForSeconds(3f);

        StartCoroutine("ChangeMovement");
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.tag == "Player")
        {
            Debug.Log("OVER");
            other.gameObject.SetActive(false);

            canvas.gameObject.SetActive(true);
        }

    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if(other.gameObject.tag  == "Player")
        {
            traceTarget = other.gameObject;

            StartCoroutine("ChangeMovement");
        }
    }

    void OnTriggerStay2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            isTracing = true;

            animator.SetBool("isMoving", true);
        }

        // if(transform.position.x == playerPos.x)
    }
    void OnTriggerExit2D(Collider2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            isTracing = false;

            StartCoroutine("ChangeMovement");
        }
    }

    public void gameReStart()
    {
        SceneManager.LoadScene(0);
        canvas.alpha = 0;
    }
}
